import { createServer } from "./src/app";

createServer();
